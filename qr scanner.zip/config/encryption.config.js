module.exports = {
  key: '4f2062ae99d1242453a31b03dfd08e1f',
  iv: '1fa042c439b6b60d'
}