# myfoodbox-backend

1. change database credentials under config section.
2. `npm install` to install pacages
3. `npm start` to start server.
